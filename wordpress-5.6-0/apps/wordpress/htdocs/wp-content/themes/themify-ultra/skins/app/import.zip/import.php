<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 6,
  'post_date' => '2018-05-25 20:19:29',
  'post_date_gmt' => '2018-05-25 20:19:29',
  'post_content' => '<!--themify_builder_static--><h1>Ultra App</h1> <p>Speed up your mobile app development now. Simple 5-min installation. Available both on iOS and Android.</p>
<a href="https://themify.me/" > DOWNLOAD </a>
<a href="https://www.youtube.com/watch?v=P8Lte26BBN8" > <img src="https://themify.me/demo/themes/ultra-app/files/2018/05/ipad-app-689x506.png" width="689" alt="ipad app" srcset="https://themify.me/demo/themes/ultra-app/files/2018/05/ipad-app.png 689w, https://themify.me/demo/themes/ultra-app/files/2018/05/ipad-app-300x220.png 300w" sizes="(max-width: 689px) 100vw, 689px" /> </a>
<h2>Quick Prototypes</h2> <p>Perfect for presenting your apps, websites and prototypes. Mainstream your design and development process without hassle exports. Simply export it any time as you want. Available to view online or any mobile device.</p>
<a href="https://themify.me/" > WATCH IT </a>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/app-interface-670x481.png" width="670" alt="app interface" srcset="https://themify.me/demo/themes/ultra-app/files/2018/05/app-interface-670x481.png 670w, https://themify.me/demo/themes/ultra-app/files/2018/05/app-interface-300x216.png 300w, https://themify.me/demo/themes/ultra-app/files/2018/05/app-interface-768x552.png 768w, https://themify.me/demo/themes/ultra-app/files/2018/05/app-interface.png 948w" sizes="(max-width: 670px) 100vw, 670px" />
<h2>Testimonials</h2>
<ul data-id="tb_am52173" data-visible="3" data-mob-visible="1" data-scroll="1" data-auto-scroll="off" data-speed="1" data-wrap="yes" data-arrow="yes" data-pagination="yes" data-effect="scroll" data-height="variable" data-pause-on-hover="resume" data-play-controller="no" data-horizontal="" > <li> 
 <figure> <img src="https://themify.me/demo/themes/ultra-app/files/2018/05/testimonial-client-1-100x100.jpg" width="100" height="100" alt="testimonial-client-1" /> </figure> <p>Thanks Plentific for helping us stay on top of a very stressful process! Finally exchanged and looking forward to complete.</p> Hendry Bradshaw Evernote </li> <li> 
 <figure> <img src="https://themify.me/demo/themes/ultra-app/files/2018/05/testimonial-client-2-100x100.jpg" width="100" height="100" alt="testimonial-client-2" /> </figure> <p>Great to stay on top of the process. Especially liked to play with the financial section when viewing properties. Highly recommended!</p> Andree Shorter Invision </li> <li> 
 <figure> <img src="https://themify.me/demo/themes/ultra-app/files/2018/05/testimonial-client-3-100x100.jpg" width="100" height="100" alt="testimonial-client-3" /> </figure> <p>Just started flat hunting. Your affordability calculator saved me some serious time to focus on what I can actually buy. Thanks so much.</p> Sofia Gerald AirBNB </li> <li> 
 <figure> <img src="https://themify.me/demo/themes/ultra-app/files/2018/05/testimonial-client-4-100x100.jpg" width="100" height="100" alt="testimonial-client-4" /> </figure> <p>Thumbs Up, their service is magnificent, quick solution for top enterprise. Totally recommended App for your business</p> Chintya Abee Total Solution </li> </ul>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/client-1-156x39.png" width="156" alt="client 1" srcset="https://themify.me/demo/themes/ultra-app/files/2018/05/client-1.png 156w, https://themify.me/demo/themes/ultra-app/files/2018/05/client-1-150x39.png 150w" sizes="(max-width: 156px) 100vw, 156px" />
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/client-2-143x37.png" width="143" alt="client 2" />
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/client-3-51x36.png" width="51" alt="client 3" />
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/client-4-126x37.png" width="126" alt="client 4" />
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/client-5-163x37.png" width="163" alt="client 5" />
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/client-6-116x35.png" width="116" alt="client 6" />
<h2>Features</h2>
<p>Deserun mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. Excepteur sint occaecat cupidatat.</p>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/camera-app-icon-1.png" alt="Camera" /> 
 
 <h3> Camera </h3> <p>Sed ut perspiciatis unde omnis iste natus error.</p>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/share-app-icon-1.png" alt="Share" /> 
 
 <h3> Share </h3> <p>Excepteur sint occaecat cupidatat non proident.</p>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/sync-app-icon-1.png" alt="Sync" /> 
 
 <h3> Sync </h3> <p>At vero eos et accusamus et iusto odio dignissimos.</p>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/11/iphone-345x679.png" width="345" alt="iphone" srcset="https://themify.me/demo/themes/ultra-app/files/2018/11/iphone.png 345w, https://themify.me/demo/themes/ultra-app/files/2018/11/iphone-152x300.png 152w" sizes="(max-width: 345px) 100vw, 345px" />
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/filter-app-icon-1.png" alt="Filter" /> 
 
 <h3> Filter </h3> <p>Neque porro quisquam est, qui dolorem ipsum quiat.</p>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/edit-app-icon-1.png" alt="Edit" /> 
 
 <h3> Edit </h3> <p>Nemo enim ipsam voluptatem quia voluptas.</p>
<img src="https://themify.me/demo/themes/ultra-app/files/2018/05/effect-app-icon-1.png" alt="Effects" /> 
 
 <h3> Effects </h3> <p>Nam libero tempore, cum soluta nobis est eligendi.</p>
Lite $5.99 <p>/ month</p> 1 User 100 Exports 100 Prototypes <a href="https://themify.me"> Buy Now </a>
Popular Pro $9.99 <p>/ month</p> 5 Users 1000 Exports 1000 Prototypes <a href="https://themify.me"> Buy Now </a>
Master $24.99 <p>/ month</p> Unlimited Users Unlimited Exports Unlimited Prototypes <a href="https://themify.me"> Buy Now </a>
<h2>Got Questions?</h2> <p>Don’t be shy. We are here to answer your questions 24/7.</p>
<form action="https://themify.me/demo/themes/ultra-app/wp-admin/admin-ajax.php" id="contact-0--form" method="post"> <label for="contact-0--contact-name">Your Name </label> <input type="text" name="contact-name" placeholder="" id="contact-0--contact-name" value="" /> <label for="contact-0--contact-email">Your Email </label> <input type="text" name="contact-email" placeholder="" id="contact-0--contact-email" value="" /> <label for="contact-0--contact-subject">Subject *</label> <input type="text" name="contact-subject" placeholder="" id="contact-0--contact-subject" value="" required /> <label for="contact-0--contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="contact-0--contact-message" rows="8" cols="45" required></textarea> <button type="submit"> Send </button> </form><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2020-02-05 09:27:11',
  'post_modified_gmt' => '2020-02-05 09:27:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-app/?page_id=6',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'mobile_menu_styles' => 'default',
    'header_wrap' => 'transparent',
    'post_filter' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"c5yf170\\",\\"cols\\":[{\\"element_id\\":\\"j5vx171\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ye3e171\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h1>Ultra App<\\\\/h1>\\\\n<p>Speed up your mobile app development now. Simple 5-min installation. Available both on iOS and Android.<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"6v52171\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"DOWNLOAD\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"buttons_shape\\":\\"circle\\"}}],\\"styling\\":{\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"14\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}},{\\"element_id\\":\\"169r171\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"m2z8171\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/ipad-app.png\\",\\"width_image\\":\\"689\\",\\"link_image\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/watch?v=P8Lte26BBN8\\",\\"param_image\\":\\"lightbox\\",\\"animation_effect\\":\\"fadeInUp\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/bg-header.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"25\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_bottom\\":\\"-22\\",\\"margin_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"22\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_bottom\\":\\"0\\",\\"margin_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\"}}},{\\"element_id\\":\\"ki24170\\",\\"cols\\":[{\\"element_id\\":\\"on7y172\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"j815172\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"font_color_h2\\":\\"#405cc2\\",\\"content_text\\":\\"<h2>Quick Prototypes<\\\\/h2>\\\\n<p>Perfect for presenting your apps, websites and prototypes. Mainstream your design and development process without hassle exports. Simply export it any time as you want. Available to view online or any mobile device.<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"g29o172\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"buttons_style\\":\\"circle\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"WATCH IT\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"purple\\",\\"icon_alignment\\":\\"left\\"}]}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"padding_bottom\\":\\"14\\"}}},{\\"element_id\\":\\"1415172\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"hscb172\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/app-interface.png\\",\\"width_image\\":\\"670\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"0\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"padding_bottom\\":\\"12\\"},\\"row_width\\":\\"fullwidth-content\\",\\"row_anchor\\":\\"about\\"}},{\\"element_id\\":\\"z529170\\",\\"cols\\":[{\\"element_id\\":\\"whwe172\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"06y4173\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"font_color_h2\\":\\"#405cc2\\",\\"content_text\\":\\"<h2>Testimonials<\\\\/h2>\\"}},{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"am52173\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_container_padding_apply_all\\":\\"1\\",\\"checkbox_container_border_apply_all\\":\\"1\\",\\"checkbox_content_padding_apply_all\\":\\"1\\",\\"checkbox_content_border_apply_all\\":\\"1\\",\\"layout_testimonial\\":\\"image-top\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>Thanks Plentific for helping us stay on top of a very stressful process! Finally exchanged and looking forward to complete.<\\\\/p>\\",\\"person_picture_testimonial\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/testimonial-client-1.jpg\\",\\"person_name_testimonial\\":\\"Hendry Bradshaw\\",\\"company_testimonial\\":\\"Evernote\\"},{\\"content_testimonial\\":\\"<p>Great to stay on top of the process. Especially liked to play with the financial section when viewing properties. Highly recommended!<\\\\/p>\\",\\"person_picture_testimonial\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/testimonial-client-2.jpg\\",\\"person_name_testimonial\\":\\"Andree Shorter\\",\\"company_testimonial\\":\\"Invision\\"},{\\"content_testimonial\\":\\"<p>Just started flat hunting. Your affordability calculator saved me some serious time to focus on what I can actually buy. Thanks so much.<\\\\/p>\\",\\"person_picture_testimonial\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/testimonial-client-3.jpg\\",\\"person_name_testimonial\\":\\"Sofia Gerald\\",\\"company_testimonial\\":\\"AirBNB\\"},{\\"content_testimonial\\":\\"<p>Thumbs Up, their service is magnificent, quick solution for top enterprise. Totally recommended App for your business<\\\\/p>\\",\\"person_picture_testimonial\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/testimonial-client-4.jpg\\",\\"person_name_testimonial\\":\\"Chintya Abee\\",\\"company_testimonial\\":\\"Total Solution\\"}],\\"img_w_slider\\":\\"100\\",\\"img_h_slider\\":\\"100\\",\\"visible_opt_slider\\":\\"3\\",\\"mob_visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"height_slider\\":\\"variable\\",\\"animation_effect\\":\\"fadeIn\\"}}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_anchor\\":\\"testimonials\\"}},{\\"element_id\\":\\"nyh2170\\",\\"cols\\":[{\\"element_id\\":\\"kv9h173\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"tzvy173\\",\\"cols\\":[{\\"element_id\\":\\"eoct173\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"z88r173\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/client-1.png\\",\\"width_image\\":\\"156\\",\\"param_image\\":\\"regular\\"}}]},{\\"element_id\\":\\"k0sl173\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"48rv174\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/client-2-143x37.png\\",\\"width_image\\":\\"143\\",\\"param_image\\":\\"regular\\"}}]},{\\"element_id\\":\\"7pm5174\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vxgd174\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/client-3-51x36.png\\",\\"width_image\\":\\"51\\",\\"param_image\\":\\"regular\\"}}]},{\\"element_id\\":\\"t81g174\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"hmng174\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/client-4-126x37.png\\",\\"width_image\\":\\"126\\",\\"param_image\\":\\"regular\\"}}]},{\\"element_id\\":\\"rys6174\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"6avv174\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/client-5-163x37.png\\",\\"width_image\\":\\"163\\",\\"param_image\\":\\"regular\\"}}]},{\\"element_id\\":\\"3lee174\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3vdu175\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/client-6-116x35.png\\",\\"width_image\\":\\"116\\",\\"param_image\\":\\"regular\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_mobile\\":\\"column3-1 tb_3col\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"60\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"80\\",\\"padding_bottom\\":\\"40\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/bg-section-brand.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"27\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"17\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"row_anchor\\":\\"clients\\",\\"breakpoint_mobile\\":{\\"padding_top\\":\\"28\\",\\"padding_top_unit\\":\\"%\\"}}},{\\"element_id\\":\\"27i5170\\",\\"cols\\":[{\\"element_id\\":\\"emkj175\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"w5jz175\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"font_color_h2\\":\\"#405cc2\\",\\"content_text\\":\\"<h2>Features<\\\\/h2>\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gy2c175\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_size\\":\\"1.2\\",\\"font_size_unit\\":\\"em\\",\\"line_height\\":\\"1.9\\",\\"line_height_unit\\":\\"em\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"font_color_h2\\":\\"#405cc2\\",\\"content_text\\":\\"<p>Deserun mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. Excepteur sint occaecat cupidatat.<\\\\/p>\\"}},{\\"element_id\\":\\"h8wv175\\",\\"cols\\":[{\\"element_id\\":\\"x563176\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"gikf176\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"40\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Camera\\",\\"content_feature\\":\\"<p>Sed ut perspiciatis unde omnis iste natus error.<\\\\/p>\\",\\"layout_feature\\":\\"icon-right\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"2\\",\\"circle_color_feature\\":\\"#405cc2\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/camera-app-icon-1.png\\",\\"icon_color_feature\\":\\"#000\\",\\"link_options\\":\\"regular\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"o65s176\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"40\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Share\\",\\"content_feature\\":\\"<p>Excepteur sint occaecat cupidatat non proident.<\\\\/p>\\",\\"layout_feature\\":\\"icon-right\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"2\\",\\"circle_color_feature\\":\\"#405cc2\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/share-app-icon-1.png\\",\\"icon_color_feature\\":\\"#000\\",\\"link_options\\":\\"regular\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"rx9u176\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"40\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Sync\\",\\"content_feature\\":\\"<p>At vero eos et accusamus et iusto odio dignissimos.<\\\\/p>\\",\\"layout_feature\\":\\"icon-right\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"2\\",\\"circle_color_feature\\":\\"#405cc2\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/sync-app-icon-1.png\\",\\"icon_feature\\":\\"fa-microchip\\",\\"icon_color_feature\\":\\"#405cc2\\",\\"link_options\\":\\"regular\\"}}]},{\\"element_id\\":\\"jr0x176\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"on4x176\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/11\\\\/iphone.png\\",\\"width_image\\":\\"345\\",\\"param_image\\":\\"regular\\",\\"animation_effect\\":\\"fadeInUp\\"}}],\\"styling\\":{\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}},{\\"element_id\\":\\"bxgv176\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"gwg3176\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"40\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Filter\\",\\"content_feature\\":\\"<p>Neque porro quisquam est, qui dolorem ipsum quiat.<\\\\/p>\\",\\"layout_feature\\":\\"icon-left\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"2\\",\\"circle_color_feature\\":\\"#405cc2\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/filter-app-icon-1.png\\",\\"icon_feature\\":\\"fa-microchip\\",\\"icon_color_feature\\":\\"#000\\",\\"link_options\\":\\"regular\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"teqd177\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"40\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Edit\\",\\"content_feature\\":\\"<p>Nemo enim ipsam voluptatem quia voluptas.<\\\\/p>\\",\\"layout_feature\\":\\"icon-left\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"2\\",\\"circle_color_feature\\":\\"#405cc2\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/edit-app-icon-1.png\\",\\"icon_feature\\":\\"fa-space-shuttle\\",\\"icon_color_feature\\":\\"#000\\",\\"link_options\\":\\"regular\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"rg1y177\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"40\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Effects\\",\\"content_feature\\":\\"<p>Nam libero tempore, cum soluta nobis est eligendi.<\\\\/p>\\",\\"layout_feature\\":\\"icon-left\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"2\\",\\"circle_color_feature\\":\\"#405cc2\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/effect-app-icon-1.png\\",\\"icon_feature\\":\\"fa-window-maximize\\",\\"icon_color_feature\\":\\"#823deb\\",\\"link_options\\":\\"regular\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_size\\":\\".9\\",\\"font_size_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_left_unit\\":\\"em\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_anchor\\":\\"features\\"}},{\\"element_id\\":\\"pf93170\\",\\"cols\\":[{\\"element_id\\":\\"0ede178\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"nvod178\\",\\"cols\\":[{\\"element_id\\":\\"4ltl178\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"pricing-table\\",\\"element_id\\":\\"8jd5178\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"mod_button_bg_color\\":\\"#41b838\\",\\"mod_color_pricing_table\\":\\"green\\",\\"mod_title_pricing_table\\":\\"Lite\\",\\"mod_price_pricing_table\\":\\"$5.99\\",\\"mod_description_pricing_table\\":\\"\\\\/ month\\",\\"mod_feature_list_pricing_table\\":\\"1 User\\\\n100 Exports\\\\n100 Prototypes\\",\\"mod_button_text_pricing_table\\":\\"Buy Now\\",\\"mod_button_link_pricing_table\\":\\"https:\\\\/\\\\/themify.me\\"}}]},{\\"element_id\\":\\"z843178\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"pricing-table\\",\\"element_id\\":\\"vgwa178\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"mod_button_bg_color\\":\\"#7b21e6\\",\\"mod_pop_font_color\\":\\"#ffffff\\",\\"mod_color_pricing_table\\":\\"purple\\",\\"mod_title_pricing_table\\":\\"Pro\\",\\"mod_price_pricing_table\\":\\"$9.99\\",\\"mod_description_pricing_table\\":\\"\\\\/ month\\",\\"mod_feature_list_pricing_table\\":\\"5 Users\\\\n1000 Exports\\\\n1000 Prototypes\\",\\"mod_button_text_pricing_table\\":\\"Buy Now\\",\\"mod_button_link_pricing_table\\":\\"https:\\\\/\\\\/themify.me\\",\\"mod_pop_text_pricing_table\\":\\"Popular\\",\\"mod_enlarge_pricing_table\\":\\"enlarge\\"}}]},{\\"element_id\\":\\"jdls178\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"pricing-table\\",\\"element_id\\":\\"7a9e179\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"mod_button_bg_color\\":\\"#41b838\\",\\"mod_color_pricing_table\\":\\"green\\",\\"mod_title_pricing_table\\":\\"Master\\",\\"mod_price_pricing_table\\":\\"$24.99\\",\\"mod_description_pricing_table\\":\\"\\\\/ month\\",\\"mod_feature_list_pricing_table\\":\\"Unlimited Users\\\\nUnlimited Exports\\\\nUnlimited Prototypes\\",\\"mod_button_text_pricing_table\\":\\"Buy Now\\",\\"mod_button_link_pricing_table\\":\\"https:\\\\/\\\\/themify.me\\"}}]}]}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_speed\\":\\"2000\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-app\\\\/files\\\\/2018\\\\/05\\\\/bg-pricing.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"background_repeat_inner\\":\\"repeat\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_position_inner\\":\\"center-center\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"border_inner-type\\":\\"top\\",\\"top-frame_type\\":\\"top-presets\\",\\"bottom-frame_type\\":\\"bottom-presets\\",\\"left-frame_type\\":\\"left-presets\\",\\"right-frame_type\\":\\"right-presets\\",\\"padding_top\\":\\"11\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"18\\",\\"padding_bottom_unit\\":\\"%\\",\\"border-type\\":\\"top\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"},\\"row_width\\":\\"fullwidth\\",\\"row_anchor\\":\\"pricing\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_color_h3\\":\\"#ffffff\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"element_id\\":\\"8229170\\",\\"cols\\":[{\\"element_id\\":\\"p4zj179\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"55li179\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"font_color_h2\\":\\"#405cc2\\",\\"content_text\\":\\"<h2>Got Questions?<\\\\/h2>\\\\n<p>Don’t be shy. We are here to answer your questions 24\\\\/7.<\\\\/p>\\"}},{\\"element_id\\":\\"76hs179\\",\\"cols\\":[{\\"element_id\\":\\"4zyd179\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"rybz179\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"3hys179\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_border_inputs_apply_all\\":\\"1\\",\\"checkbox_border_send_apply_all\\":\\"1\\",\\"checkbox_padding_success_message_apply_all\\":\\"1\\",\\"checkbox_margin_success_message_apply_all\\":\\"1\\",\\"checkbox_border_success_message_apply_all\\":\\"1\\",\\"checkbox_padding_error_message_apply_all\\":\\"1\\",\\"checkbox_margin_error_message_apply_all\\":\\"1\\",\\"checkbox_border_error_message_apply_all\\":\\"1\\",\\"layout_contact\\":\\"animated-label\\",\\"field_name_label\\":\\"Your Name\\",\\"field_email_label\\":\\"Your Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_subject_require\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_message_label\\":\\"Message\\",\\"field_extra\\":\\"{ \\\\\\"fields\\\\\\": [] }\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_order\\":\\"{}\\",\\"field_send_label\\":\\"Send\\",\\"field_send_align\\":\\"center\\",\\"field_email_active\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"contact_sent_from\\":\\"enable\\",\\"send_to_admins\\":\\"true\\"}}]},{\\"element_id\\":\\"bouh180\\",\\"grid_class\\":\\"col4-1\\"}],\\"gutter\\":\\"gutter-none\\"}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_anchor\\":\\"contact\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 135,
  'post_date' => '2018-05-27 16:19:29',
  'post_date_gmt' => '2018-05-27 16:19:29',
  'post_content' => '',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2018-05-27 23:20:57',
  'post_modified_gmt' => '2018-05-27 23:20:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-app/?p=135',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '135',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#about',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 136,
  'post_date' => '2018-05-27 16:19:29',
  'post_date_gmt' => '2018-05-27 16:19:29',
  'post_content' => '',
  'post_title' => 'Testimonials',
  'post_excerpt' => '',
  'post_name' => 'testimonials',
  'post_modified' => '2018-05-27 23:20:57',
  'post_modified_gmt' => '2018-05-27 23:20:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-app/?p=136',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '136',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#testimonials',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 137,
  'post_date' => '2018-05-27 16:19:29',
  'post_date_gmt' => '2018-05-27 16:19:29',
  'post_content' => '',
  'post_title' => 'Features',
  'post_excerpt' => '',
  'post_name' => 'features',
  'post_modified' => '2018-05-27 23:20:57',
  'post_modified_gmt' => '2018-05-27 23:20:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-app/?p=137',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '137',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#features',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 139,
  'post_date' => '2018-05-27 16:19:29',
  'post_date_gmt' => '2018-05-27 16:19:29',
  'post_content' => '',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2018-05-27 23:20:57',
  'post_modified_gmt' => '2018-05-27 23:20:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-app/?p=139',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '139',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#contact',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 140,
  'post_date' => '2018-05-27 16:19:29',
  'post_date_gmt' => '2018-05-27 16:19:29',
  'post_content' => '',
  'post_title' => 'Download',
  'post_excerpt' => '',
  'post_name' => 'download',
  'post_modified' => '2018-05-27 23:20:57',
  'post_modified_gmt' => '2018-05-27 23:20:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-app/?p=140',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '140',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => 'highlight-link',
    ),
    '_menu_item_url' => '#pricing',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_search" );
$widgets[1002] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1003] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1004] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1006] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1008] = array (
  'title' => 'Office',
  'text' => '55 Adelaide St E, 
Toronto, ON, M5C 1K6
Canada',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1009] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-large',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'search-1002',
    1 => 'recent-posts-1003',
    2 => 'recent-comments-1004',
    3 => 'archives-1005',
    4 => 'categories-1006',
    5 => 'meta-1007',
  ),
  'footer-widget-1' => 
  array (
    0 => 'text-1008',
  ),
  'footer-widget-2' => 
  array (
    0 => 'themify-social-links-1009',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-cache-live' => '10080',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout_display' => 'content',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-custom_post_tglobal_style_single' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_index_post_meta_category' => 'yes',
  'setting-default_portfolio_index_unlink_post_image' => 'yes',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'setting-default_portfolio_single_unlink_post_image' => 'yes',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-customizer_responsive_design_tablet_landscape' => '1280',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '680',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-exclude_rss' => 'on',
  'setting-exclude_header_widgets' => 'on',
  'setting-header_widgets' => 'headerwidget-3col',
  'setting-footer_design' => 'footer-left-col',
  'setting-exclude_footer_menu_navigation' => 'on',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-2col',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-app/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-app/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'Google+',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-app/wp-content/themes/themify-ultra/themify/img/social/google-plus.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'YouTube',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-app/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-4' => 'image-icon',
  'setting-link_title_themify-link-4' => 'Pinterest',
  'setting-link_img_themify-link-4' => 'https://themify.me/demo/themes/ultra-app/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'Facebook',
  'setting-link_link_themify-link-6' => 'http://facebook.com/themify',
  'setting-link_ficon_themify-link-6' => 'fa-facebook',
  'setting-link_ficolor_themify-link-6' => '#ffffff',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Twitter',
  'setting-link_link_themify-link-5' => 'http://twitter.com/themify',
  'setting-link_ficon_themify-link-5' => 'fa-twitter',
  'setting-link_ficolor_themify-link-5' => '#ffffff',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_title_themify-link-8' => 'Instagram',
  'setting-link_link_themify-link-8' => 'https://instagram.com/themify',
  'setting-link_ficon_themify-link-8' => 'fa-instagram',
  'setting-link_ficolor_themify-link-8' => '#ffffff',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-6":"themify-link-6","themify-link-5":"themify-link-5","themify-link-8":"themify-link-8"}',
  'setting-link_field_hash' => '10',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'app',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
  'footerwrap_background' => '{"id":"","src":"","style":"","position":"","noimage":"","transparent":""}',
  'footerwrap_padding' => '{"top":{"width":"","unit":"px"},"left":{"width":"","unit":"px"},"bottom":{"width":"","unit":"px"},"right":{"width":"","unit":"px"},"same":"","width":"","unit":"px"}',
  'footer_color' => '{"color":"ffffff","opacity":"1.00"}',
  'site-logo_image' => '{"stamp":1527633301189}',
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
